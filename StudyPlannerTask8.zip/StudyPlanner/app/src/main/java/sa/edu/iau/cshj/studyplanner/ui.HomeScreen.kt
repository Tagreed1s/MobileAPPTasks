package sa.edu.iau.cshj.studyplanner.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun PlannerHomeScreen(
    uiState: PlannerUiState,
    onTaskClick: (Int) -> Unit,
    onDoneChange: (Int, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = uiState.greeting,
            style = MaterialTheme.typography.headlineMedium
        )

        Text(
            text = "${uiState.completedTasks} of ${uiState.totalTasks} done",
            style = MaterialTheme.typography.bodyLarge
        )

        Text(
            text = "Study Tasks",
            style = MaterialTheme.typography.titleLarge
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(
                items = uiState.tasks,
                key = { it.id }
            ) { task ->
                TaskItem(
                    task = task,
                    onTaskClick = onTaskClick,
                    onDoneChange = onDoneChange
                )
            }
        }
    }
}

@Composable
fun PlannerHomeRoute(
    onTaskClick: (String) -> Unit = {}
) {
    var uiState by remember {
        mutableStateOf(
            PlannerUiState(
                tasks = listOf(
                    StudyTask(
                        id = 1,
                        title = "Review Kotlin",
                        course = "Mobile Development"
                    ),
                    StudyTask(
                        id = 2,
                        title = "Study Navigation",
                        course = "Mobile Development"
                    ),
                    StudyTask(
                        id = 3,
                        title = "Finish Lab 5 Report",
                        course = "Programming"
                    )
                )
            )
        )
    }

    PlannerHomeScreen(
        uiState = uiState,
        onTaskClick = { taskId ->
            val task = uiState.tasks.find {
                it.id == taskId
            }
            task?.let {
                onTaskClick(it.title)
            }
        },
        onDoneChange = { taskId, isDone ->
            uiState = uiState.copy(
                tasks = uiState.tasks.map { task ->
                    if (task.id == taskId) {
                        task.copy(isDone = isDone)
                    } else {
                        task
                    }
                }
            )
        }
    )
}

private val previewTasks = listOf(
    StudyTask(
        id = 1,
        title = "Review Kotlin",
        course = "Mobile Development"
    ),
    StudyTask(
        id = 2,
        title = "Study Navigation",
        course = "Mobile Development"
    ),
    StudyTask(
        id = 3,
        title = "Finish Lab 5 Report",
        course = "Programming"
    )
)

@Preview(showBackground = true, name = "Nothing Done")
@Composable
private fun PlannerHomeScreenPreviewEmpty() {
    MaterialTheme {
        PlannerHomeScreen(
            uiState = PlannerUiState(
                tasks = previewTasks
            ),
            onTaskClick = {},
            onDoneChange = { _, _ -> }
        )
    }
}

@Preview(showBackground = true, name = "Some Completed")
@Composable
private fun PlannerHomeScreenPreviewPartial() {
    MaterialTheme {
        PlannerHomeScreen(
            uiState = PlannerUiState(
                tasks = previewTasks.map { task ->
                    if (task.id == 1) {
                        task.copy(isDone = true)
                    } else {
                        task
                    }
                }
            ),
            onTaskClick = {},
            onDoneChange = { _, _ -> }
        )
    }
}

@Preview(showBackground = true, name = "All Completed")
@Composable
private fun PlannerHomeScreenPreviewFull() {
    MaterialTheme {
        PlannerHomeScreen(
            uiState = PlannerUiState(
                tasks = previewTasks.map {
                    it.copy(isDone = true)
                }
            ),
            onTaskClick = {},
            onDoneChange = { _, _ -> }
        )
    }
}
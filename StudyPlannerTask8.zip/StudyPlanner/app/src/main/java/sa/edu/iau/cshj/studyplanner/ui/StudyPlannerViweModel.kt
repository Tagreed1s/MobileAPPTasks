package sa.edu.iau.cshj.studyplanner.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class StudyPlannerViewModel : ViewModel() {

    var uiState by mutableStateOf(
        PlannerUiState(
            tasks = listOf(
                StudyTask(
                    id = 1,
                    title = "Review Kotlin",
                    course = "Mobile Development"
                ),
                StudyTask(
                    id = 2,
                    title = "Study Navigation",
                    course = "Mobile Development"
                ),
                StudyTask(
                    id = 3,
                    title = "Finish Lab 5 Report",
                    course = "Programming"
                )
            )
        )
    )
        private set

    fun addTask(title: String) {
        val newTask = StudyTask(
            id = (uiState.tasks.maxOfOrNull { it.id } ?: 0) + 1,
            title = title,
            course = "General"
        )

        uiState = uiState.copy(
            tasks = uiState.tasks + newTask
        )
    }

    fun completeTask(taskId: Int, isDone: Boolean) {
        uiState = uiState.copy(
            tasks = uiState.tasks.map { task ->
                if (task.id == taskId) {
                    task.copy(isDone = isDone)
                } else {
                    task
                }
            }
        )
    }
}
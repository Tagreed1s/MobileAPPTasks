package sa.edu.iau.cshj.studyplanner.ui



data class PlannerUiState(
    val greeting: String = "Welcome back!",
    val tasks: List<StudyTask> = emptyList()
) {
    val totalTasks: Int
        get() = tasks.size

    val completedTasks: Int
        get() = tasks.count { it.isDone }
}